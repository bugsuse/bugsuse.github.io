Examples
========

This directory contains a script (``plot-examples.py``) to generate the example plots. The results are in ``figures/``.
